﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HeroStateMachine : MonoBehaviour
{
	public bool earlyReturn;
	public bool battleAnim;
	public bool running;
	public int j;
	public bool dontattackme;
	public bool atPosition;
	public BaseHero hero;
	private BattleStateMachine BSM;
	private BattleStateMachine BSM2;
	public GameObject BSMa;
	public Animation stickcleave;
	private GameManager GMan;
	public GameObject GMana;
	public bool isCombo;
	public EnemyStateMachine ESM;

	public enum TurnState
	{
		PROCESSING, //bar fills
		ADDTOLIST, //add hero to a list
		WAITING, //idle state
		SELECTING, //player selects action which we create later on
		ACTION, //can do an action
		DEAD
	}

	public TurnState currentState;
	//for the progress bar
	public bool attacking;
	private float cur_cooldown = 0f;
	private float max_cooldown = 5f;
	public Image ProgressBar;
	public GameObject Selector;

	public GameObject EnemyToAttack;
	public Animator playerAnimator;
	private bool actionStarted = false;
	private Vector3 startposition;
	private float animSpeed = 10f;
	private bool alive = true;
	//hero Panel
	private HeroPanelStats stats;
	public GameObject HeroPanel;
	private Transform HeroPanelSpacer;
	public GameObject apText;
	Text AP_Text;
	// Use this for initialization
	void Start()
	{
		//ap_update();
		//GameObject ApText = Instantiate(apText) as GameObject;//change text inside of button bottom
		AP_Text = GameObject.Find("Hero 1").GetComponent<HeroStateMachine>().apText.gameObject.GetComponent<Text>(); 
		//AP_Text = ApText.transform.Find("Text").gameObject.GetComponent<Text>();

		earlyReturn = false;
		battleAnim = false;
		running = false;
		isCombo = false;
		GMana = GameObject.Find("GameManager");
		BSMa = GameObject.Find("BattleManager");
		playerAnimator = GameObject.Find("Hero 1").GetComponent<Animator>();
		GMan = GMana.GetComponent<GameManager>();
		BSM2 = BSMa.GetComponent<BattleStateMachine>();
		HeroPanelSpacer = GameObject.Find("BattleCanvas").transform.Find("HeroPanel").transform.Find("HeroPanelSpacer");
		CreateHeroPanel();
		//create panel, fill in info 


		//find spacer
		startposition = transform.position;
		cur_cooldown = Random.Range(0, 2.5f);
		Selector.SetActive(false);
		BSM = GameObject.Find("BattleManager").GetComponent<BattleStateMachine>(); //connects enemystatemachine to battlestatemachine
		currentState = TurnState.PROCESSING;
		j = 0;
	}

	// Update is called once per frame
	void Update() //if enemy is dead automatically cancel and run back
	{
		
			StartCoroutine(waitingForCompletion());
		if (!isCombo)
		{
			ap_update();
		}


		if ((Input.GetKeyDown(KeyCode.S) == true) && attacking != true && isCombo && !running && !battleAnim && !earlyReturn)
		{
			dontattackme = true;
			Debug.Log("Perform list");
			//BSM.PerformList.RemoveAt(0);
			isCombo = false;
			StartCoroutine(ReturnToSpot());


			GMan.ap += 3;
			ap_update();
			BSM.ComboPanel.SetActive(false);
		
			//reset BSM -> WAIT
			if (!dontattackme)
			{


				Debug.Log("Removing performlist!");

			}
			dontattackme = true;

			//reset BSM -> WAIT
		}
		/*if ((Input.GetKeyDown(KeyCode.S) == true) && isCombo && !attacking && atPosition)	
		{
			Debug.Log("Perform list");
			//BSM.PerformList.RemoveAt(0);
			isCombo = false;
			StartCoroutine(ReturnToSpot());
			BSM.PerformList.RemoveAt(0);

			GMan.ap = 3;
			BSM.ComboPanel.SetActive(false);
			//reset BSM -> WAIT
			if (BSM.battleStates != BattleStateMachine.PerformAction.WIN && BSM.battleStates != BattleStateMachine.PerformAction.LOSE)
			{
				BSM.battleStates = BattleStateMachine.PerformAction.WAIT;
				cur_cooldown = 0f;
				currentState = TurnState.PROCESSING;

			}
			//reset the battle state machine and set monster to wait
			Debug.Log("Perform Action Wait");
			BSM.battleStates = BattleStateMachine.PerformAction.WAIT;
			//end coroutine
			Debug.Log("Action false");
			actionStarted = false;
			//reset this enemy state
			Debug.Log("Current cooldown = 0");
			cur_cooldown = 0f;
			Debug.Log("Turnstate.PROCESSING");
			currentState = TurnState.PROCESSING;
		}
		*/
		if (Input.GetKeyDown(KeyCode.W) == true && attacking != true && isCombo)
		{
			GMan.ap -= 2;
			playerAnimator.Play("stickcleave");
			attacking = true;
			actionStarted = true;
			//yield return new WaitForSeconds(2f);
			Debug.Log("BSM Time");
			BSM2.HeroChoice.chooseanAttack = BSM2.HeroesToManage[0].GetComponent<HeroStateMachine>().hero.attacks[0]; // was 0
			Debug.Log("Damage");
			doDamage();
			Debug.Log("attacking");

			attacking = false;
			Debug.Log("stickidle");

			playerAnimator.Play("stickidle");//animate idle

		}

		else if (Input.GetKeyDown(KeyCode.A) == true && attacking != true && isCombo && !running && !battleAnim && !earlyReturn)
		{
			Debug.Log("Subtract ap");
			GMan.ap -= 1;
			ap_update();
			Debug.Log(GMan.ap);
			Debug.Log("animate cleave");
			playerAnimator.Play("stickcleave");
			attacking = true;
			BSM.HeroChoice.chooseanAttack = GameObject.Find("Hero 1").GetComponent<HeroStateMachine>().hero.attacks[0];
			StartCoroutine(AttackDelay());
			Debug.Log("attacking is true");

			Debug.Log("action started is true");
			//actionStarted = true;
			//yield return new WaitForSeconds(2f);
			Debug.Log("choose attack");
			//BSM.HeroChoice.chooseanAttack = BSM.HeroesToManage[0].GetComponent<HeroStateMachine>().hero.attacks[0]; // was 1
			
			Debug.Log("damage");
			//	doDamage();

			attacking = false;
			Debug.Log("stickidle");

			//playerAnimator.Play("stickrunning");
		}

		else if (Input.GetKeyDown(KeyCode.D) == true && attacking != true && isCombo)
		{
			GMan.ap -= 1;
			playerAnimator.Play("stickcleave");
			attacking = true;
			actionStarted = true;
			//yield return new WaitForSeconds(2f);
			BSM.HeroChoice.chooseanAttack = BSM.HeroesToManage[0].GetComponent<HeroStateMachine>().hero.attacks[0]; //was 2
			doDamage();
			attacking = false;
			playerAnimator.Play("stickidle");//animate idle

		}


		if (Input.GetKeyDown(KeyCode.S) == true)
			Debug.Log("HOO!");
		//Debug.Log(currentState);

		switch (currentState)
		{

			case (TurnState.PROCESSING):
				UpdateProgressBar();
				break;

			case (TurnState.ADDTOLIST):
				BSM.HeroesToManage.Add(this.gameObject);
				currentState = TurnState.WAITING;
				break;

			case (TurnState.WAITING):
				//idle
				break;

			case (TurnState.SELECTING):

				break;

			case (TurnState.ACTION):
				StartCoroutine(TimeForAction());
				break;

			case (TurnState.DEAD):
				if (!alive)
				{
					return;
				}
				else
				{
					this.gameObject.tag = "DeadHero";
					//change tag

					//change attackable by enemy 

					BSM.HeroesInBattle.Remove(this.gameObject);

					//not able to manage hero anymore

					BSM.HeroesToManage.Remove(this.gameObject);

					//deactive the selector if it's on

					Selector.SetActive(false);

					//reset gui (get rid of attack / select panel)

					BSM.AttackPanel.SetActive(false);
					BSM.EnemySelectPanel.SetActive(false);
					//remove item from performlist

					if (BSM.HeroesInBattle.Count > 0)
					{
						for (int i = 0; i < BSM.PerformList.Count; i++)
						{
							if (i != 0)
							{
								if (BSM.PerformList[i].AttackersGameObject == this.gameObject) //if we are current attacker
								{
									BSM.PerformList.Remove(BSM.PerformList[i]);

								}

								else if (BSM.PerformList[i].AttackersTarget == this.gameObject)
								{
									BSM.PerformList[i].AttackersTarget = BSM.HeroesInBattle[Random.Range(0, BSM.HeroesInBattle.Count)];
								}
							}
						}
					}
					//change color / play animation

					this.gameObject.GetComponent<SpriteRenderer>().material.color = new Color32(105, 105, 105, 255);

					BSM.battleStates = BattleStateMachine.PerformAction.CHECKALIVE; //if other hero is alive.
					alive = false;

					//reset the heroinput


					alive = false;
				}
				break;


		}


	}

	void UpdateProgressBar()
	{

		cur_cooldown = cur_cooldown + Time.deltaTime;
		float calc_cooldown = cur_cooldown / max_cooldown;
		ProgressBar.transform.localScale = new Vector3(Mathf.Clamp(calc_cooldown, 0, 1), ProgressBar.transform.localScale.y, ProgressBar.transform.localScale.z);
		if (cur_cooldown >= max_cooldown)
		{
			currentState = TurnState.ADDTOLIST;
		}
	}

	private IEnumerator AttackDelay()
	{
		actionStarted = true;

		actionStarted = true;
		attacking = true;
		if (attacking)
			Debug.Log("ATTACKING!");
		Debug.Log("AttackDelay");
		//stickcleave = GameObject.Find("Hero 1").GetComponent<Animation>().name;
		RuntimeAnimatorController ac = playerAnimator.runtimeAnimatorController;
		for (int i = 0; i < ac.animationClips.Length; i++)
		{
			Debug.Log(ac.animationClips[i].name);
			if (ac.animationClips[i].name == "stickcleave")
			{
				Debug.Log("stickcleave timetowait");
				battleAnim = true;
				yield return new WaitForSeconds(ac.animationClips[i].length);
				doDamage(); //switched places with button command in update
				if (BSM.PerformList[0].Type == "Hero")
				{
					//EnemyStateMachine ESM = performer.GetComponent<EnemyStateMachine>();//catch enemy statemachine
					for (int k = 0; k < BSM.EnemiesInBattle.Count; k++)//check if currently dead hero is in battle list
					{
						Debug.Log("Current number of enemies in battle: " + k + 1);
						//EnemyStateMachine tempEnemy = GameObject.Find(BSM.PerformList[0].AttackersTarget.name).GetComponent<EnemyStateMachine>().currentState;
						//if (tempEnemy.TurnState != DEAD)
							if (GameObject.Find(BSM.PerformList[0].AttackersTarget.name).GetComponent<EnemyStateMachine>().currentState != EnemyStateMachine.TurnState.DEAD)
						//if (BSM.PerformList[0].AttackersTarget == BSM.EnemiesInBattle[k])
						{
							Debug.Log("Attacked same person!");
							EnemyToAttack = BSM.PerformList[0].AttackersTarget;
							currentState = TurnState.ACTION;
							break;
						}
						else
						{
							Debug.Log("Early return");
							earlyReturn = true;
							StartCoroutine(ReturnToSpot());
							GMan.ap += 3;
							ap_update();
							BSM.ComboPanel.SetActive(false);
			{
								battleAnim = false;
								earlyReturn = false;
 yield break; };
			//reset BSM -> WAIT
			if (!dontattackme)
			{


				Debug.Log("Removing performlist!");

			}
			dontattackme = true;

						}
					}
				}
						
						attacking = false;
				if (!attacking)
					Debug.Log("NOT ATTACKING!");
				playerAnimator.Play("stickfigureidle");
			}


		}
		battleAnim = false;
		//if (actionStarted && GMan.ap != 0)
		//{
		//	yield break;
		//	}

		if (actionStarted && earlyReturn)
		{ earlyReturn = false;
			yield break; }
	


		if (GMan.ap == 0 || (Input.GetKeyDown(KeyCode.S) == true) && isCombo && !attacking && !earlyReturn)
		{
			dontattackme = true;
			Debug.Log("Perform list");
			//BSM.PerformList.RemoveAt(0);
			isCombo = false;
			StartCoroutine(ReturnToSpot());


			GMan.ap += 3;
			ap_update();
			BSM.ComboPanel.SetActive(false);
			{ yield break; };
			//reset BSM -> WAIT
			if (!dontattackme)
			{


				Debug.Log("Removing performlist!");

			}
			dontattackme = true;

			//reset BSM -> WAIT

		}
				earlyReturn = false;
		if (actionStarted)
		{ yield break; }
	}

	private IEnumerator waitingForCompletion()

	{
		
		yield return null; }
	private IEnumerator TimeForAction()
	{
		isCombo = true;
		if (actionStarted)
		{
			yield break;
		}
		actionStarted = true;

		//animate enemy near the hero to attack

		// run to enemy

		Vector3 heroPosition = new Vector3(EnemyToAttack.transform.position.x + 1.5f, EnemyToAttack.transform.position.y, EnemyToAttack.transform.position.z);//increasing target's x position by 1.5f units to give space to attack

		//playerAnimator.Play("stickrunleft");
		//running = true;
		//MoveTowardsEnemy(heroPosition);
		//RuntimeAnimatorController ac = playerAnimator.runtimeAnimatorController;
		while (MoveTowardsEnemy(heroPosition))
		{
			playerAnimator.Play("stickrunleft");
			running = true; 
			yield return null;
		}
		running = false;
		/*for (int i = 0; i < ac.animationClips.Length; i++)
		{
			Debug.Log(ac.animationClips[i].name);
			if (ac.animationClips[i].name == "stickrunleft")
			{
				Debug.Log("stickrunleft timetowait");
				yield return new WaitForSeconds(10f);// see if we can do an action while during wait for seconds
				running = false;
				playerAnimator.Play("stickfigureidle");
			}
		}*/


		/*while (MoveTowardsEnemy(heroPosition))
		{
			playerAnimator.Play("stickrunleft");
			yield return null;
		}*/
		atPosition = true;
		//	playerAnimator.Play("stickidle");//animate idle
		if (GMan.ap == 3)
			Debug.Log("HIYA!");
		//do { yield return new WaitForSeconds(2f); }
		//while (Input.GetKeyDown(KeyCode.S) != true);
		Debug.Log("Holy Smokes!");
		//while (Input.GetKeyDown(KeyCode.S) != true);

		/*
		while (GMan.ap != 0 || (Input.GetKeyDown(KeyCode.S) == true))
		{
			if (Input.GetKeyDown(KeyCode.W) == true && attacking != true)
			{
				GMan.ap -= 2;
				playerAnimator.Play("stickcleave");
				attacking = true;
				actionStarted = true;
				yield return new WaitForSeconds(2f);
				BSM.HeroChoice.chooseanAttack = BSM.HeroesToManage[0].GetComponent<HeroStateMachine>().hero.attacks[0]; // was 0
				doDamage();
				attacking = false;
				playerAnimator.Play("stickidle");//animate idle

			}

			else if (Input.GetKeyDown(KeyCode.A) == true && attacking != true)
			{
				GMan.ap -= 1;
				playerAnimator.Play("stickcleave");
				attacking = true;
				actionStarted = true;
				yield return new WaitForSeconds(2f);
				BSM.HeroChoice.chooseanAttack = BSM.HeroesToManage[0].GetComponent<HeroStateMachine>().hero.attacks[0]; // was 1
				doDamage();
				attacking = false;
				playerAnimator.Play("stickidle");//animate idle

			}

			else if (Input.GetKeyDown(KeyCode.D) == true && attacking != true)
			{
				GMan.ap -= 1;
				playerAnimator.Play("stickcleave");
				attacking = true;
				actionStarted = true;
				yield return new WaitForSeconds(2f);
				BSM.HeroChoice.chooseanAttack = BSM.HeroesToManage[0].GetComponent<HeroStateMachine>().hero.attacks[0]; //was 2
				doDamage();
				attacking = false;
				playerAnimator.Play("stickidle");//animate idle

			}
		}*/
		//do while loop to await command and wait for ap to either = 0 or x to be hit as cancel

		//if attack and attacking != true, play animation associated with attack; attacking = true
		//after certain length of animation attacking = false
		//animate idle when retrned

		//animate run back to spot

		//actionStarted = true;
		//yield return new WaitForSeconds(0.5f);
		//doDamage();

		Vector3 firstPosition = startposition;
		//playerAnimator.Play("stickrunning");//animate run right
		//while (MoveTowardsStart(firstPosition)) { yield return null; }
		//remove this performer from the list in BSM because you don't want him to do action twice
		Debug.Log("Animating idle");
		//playerAnimator.enabled = false;//animateidle
		//playerAnimator.enabled = true;//animateidle
		playerAnimator.Play("stickfigureidle");//animateidle

		//BSM.PerformList.RemoveAt(0);
		//reset BSM -> WAIT
		/*if (BSM.battleStates != BattleStateMachine.PerformAction.WIN && BSM.battleStates != BattleStateMachine.PerformAction.LOSE)
		{
			BSM.battleStates = BattleStateMachine.PerformAction.WAIT;
			cur_cooldown = 0f;
			currentState = TurnState.PROCESSING;

		}
		//reset the battle state machine and set monster to wait
		BSM.battleStates = BattleStateMachine.PerformAction.WAIT;
		//end coroutine
		actionStarted = false;
		//reset this enemy state
		cur_cooldown = 0f;
		currentState = TurnState.PROCESSING;*/
	}

	private IEnumerator ReturnToSpot()
	{
		if (dontattackme = false)
		{ yield break; }


		atPosition = false;
		playerAnimator.Play("stickrunning");//animate run right
		while (MoveTowardsStart(startposition))
		{   
			running = true;
			yield return null; }
		isCombo = false;
		running = false;
		
		
		BSM.PerformList.RemoveAt(0);
		playerAnimator.Play("stickfigureidle");

		dontattackme = false;
		if (BSM.battleStates != BattleStateMachine.PerformAction.WIN && BSM.battleStates != BattleStateMachine.PerformAction.LOSE)
		{
			BSM.battleStates = BattleStateMachine.PerformAction.WAIT;
			cur_cooldown = 0f;
			currentState = TurnState.PROCESSING;

		}
		//reset the battle state machine and set monster to wait

		BSM.battleStates = BattleStateMachine.PerformAction.WAIT;

		//end coroutine
		actionStarted = false;
		//reset this enemy state
		cur_cooldown = 0f;
		currentState = TurnState.PROCESSING;
		//BSM.PerformList.RemoveAt(0);
	}

	private bool MoveTowardsEnemy(Vector3 target)
	{
		return target != (transform.position = Vector3.MoveTowards(transform.position, target, animSpeed * Time.deltaTime));
	}
	private bool MoveTowardsStart(Vector3 target)
	{
		return target != (transform.position = Vector3.MoveTowards(transform.position, target, animSpeed * Time.deltaTime));
	}

	public void TakeDamage(float getDamageAmount)
	{
		hero.curHP -= getDamageAmount;//do damage to hero
		if (hero.curHP <= 0)
		{
			hero.curHP = 0; //if hp less than 0 set to 0 so no negative numbers
			currentState = TurnState.DEAD;
		}
		UpdateHeroPanel();

	}

	void doDamage()
	{
		float calc_damage = hero.curATK + BSM.PerformList[0].chooseanAttack.attackDamage;
		EnemyToAttack.GetComponent<EnemyStateMachine>().TakeDamage(calc_damage);
	}

	void CreateHeroPanel()//creates a new panel for whichever hero is dead
	{
		HeroPanel = Instantiate(HeroPanel) as GameObject;
		stats = HeroPanel.GetComponent<HeroPanelStats>();
		stats.HeroName.text = hero.theName;
		stats.HeroHP.text = "HP: " + hero.curHP;//HP: 456
		stats.HeroMP.text = "MP: " + hero.curMP;

		ProgressBar = stats.ProgressBar;
		HeroPanel.transform.SetParent(HeroPanelSpacer, false); //false takes care of the scalin

	}

	//update stats on damage / heal
	void UpdateHeroPanel()
	{
		stats.HeroHP.text = "HP: " + hero.curHP;
		//when taking damage get reduced get damage amount, and when dead we update hero panel in take damage script
	}

	void ap_update()
	{
		AP_Text.text = "" + GMan.ap;
	}
}

/*

   using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HeroStateMachine : MonoBehaviour {
   public BaseHero hero;
   private BattleStateMachine BSM;


   public enum TurnState
   {
	   PROCESSING, //bar fills
	   ADDTOLIST, //add hero to a list
	   WAITING, //idle state
	   SELECTING, //player selects action which we create later on
	   ACTION, //can do an action
	   DEAD
   }

   public TurnState currentState;
   //for the progress bar

   private float cur_cooldown = 0f;
   private float max_cooldown = 5f;
   public Image ProgressBar;
   public GameObject Selector;

   public GameObject EnemyToAttack;
   private bool actionStarted = false;
   private Vector3 startposition;
   private float animSpeed = 10f;
   private bool alive = true;
   //hero Panel
   private HeroPanelStats stats;
   public GameObject HeroPanel;
   private Transform HeroPanelSpacer;
   // Use this for initialization
   void Start () {
		   HeroPanelSpacer = GameObject.Find("BattleCanvas").transform.Find("HeroPanel").transform.Find("HeroPanelSpacer");
		   CreateHeroPanel();
	   //create panel, fill in info 


	   //find spacer
	   startposition = transform.position;
	   cur_cooldown = Random.Range(0, 2.5f);
	   Selector.SetActive(false);
	   BSM = GameObject.Find("BattleManager").GetComponent<BattleStateMachine>(); //connects enemystatemachine to battlestatemachine
	   currentState = TurnState.PROCESSING;
   }

   // Update is called once per frame
   void Update () {

	   //Debug.Log(currentState);

	   switch (currentState) {

		   case (TurnState.PROCESSING):
			   UpdateProgressBar();
			   break;

		   case (TurnState.ADDTOLIST):
			   BSM.HeroesToManage.Add(this.gameObject);
			   currentState = TurnState.WAITING;
			   break;

		   case (TurnState.WAITING):
			   //idle
			   break;

		   case (TurnState.SELECTING):

			   break;

		   case (TurnState.ACTION):
			   StartCoroutine(TimeForAction());
			   break;

		   case (TurnState.DEAD):
			   if (!alive)
			   {
				   return;
			   }
			   else 
			   {
				   this.gameObject.tag = "DeadHero";
				   //change tag

				   //change attackable by enemy 

				   BSM.HeroesInBattle.Remove(this.gameObject);

				   //not able to manage hero anymore

				   BSM.HeroesToManage.Remove(this.gameObject);

				   //deactive the selector if it's on

				   Selector.SetActive(false);

				   //reset gui (get rid of attack / select panel)

				   BSM.AttackPanel.SetActive(false);
				   BSM.EnemySelectPanel.SetActive(false);
				   //remove item from performlist

				   for (int i = 0; i < BSM.PerformList.Count; i++)
				   {
					   if (BSM.PerformList[i].AttackersGameObject == this.gameObject) //if we are current attacker
					   {
						   BSM.PerformList.Remove(BSM.PerformList[i]);

					   }
				   }
				   //change color / play animation

				   this.gameObject.GetComponent<SpriteRenderer>().material.color = new Color32(105, 105, 105, 255);

				   BSM.Heroinput = BattleStateMachine.HeroGUI.ACTIVATE; //if other hero is alive.
				   alive = false;

				   //reset the heroinput


				   alive = false;
			   }
			   break;


	   }


   }

   void UpdateProgressBar()
   {

	   cur_cooldown = cur_cooldown + Time.deltaTime;
	   float calc_cooldown = cur_cooldown / max_cooldown;
	   ProgressBar.transform.localScale = new Vector3(Mathf.Clamp(calc_cooldown, 0, 1), ProgressBar.transform.localScale.y, ProgressBar.transform.localScale.z);
	   if (cur_cooldown >= max_cooldown)
	   {
		   currentState = TurnState.ADDTOLIST;
	   }
   }

   private IEnumerator TimeForAction()
   {
	   if (actionStarted)
	   {
		   yield break;
	   }
	   actionStarted = true;

	   //animate enemy near the hero to attack

	   Vector3 heroPosition = new Vector3(EnemyToAttack.transform.position.x + 1.5f, EnemyToAttack.transform.position.y, EnemyToAttack.transform.position.z);//increasing target's x position by 1.5f units to give space to attack
	   while (MoveTowardsEnemy(heroPosition))
	   {
		   yield return null;
	   }
	   //wait a bit, do damage, and then animate the back to start position.
	   actionStarted = true;
	   yield return new WaitForSeconds(0.5f);
	   doDamage();

	   Vector3 firstPosition = startposition;
	   while (MoveTowardsStart(firstPosition)) { yield return null; }
	   //remove this performer from the list in BSM because you don't want him to do action twice
	   BSM.PerformList.RemoveAt(0);
	   //reset the battle state machine and set monster to wait
	   BSM.battleStates = BattleStateMachine.PerformAction.WAIT;
	   //end coroutine
	   actionStarted = false;
	   //reset this enemy state
	   cur_cooldown = 0f;
	   currentState = TurnState.PROCESSING;
   }

   private bool MoveTowardsEnemy(Vector3 target)
   {
	   return target != (transform.position = Vector3.MoveTowards(transform.position, target, animSpeed * Time.deltaTime));
   }
   private bool MoveTowardsStart(Vector3 target)
   {
	   return target != (transform.position = Vector3.MoveTowards(transform.position, target, animSpeed * Time.deltaTime));
   }

   public void TakeDamage(float getDamageAmount)
   {
	   hero.curHP -= getDamageAmount;//do damage to hero
	   if (hero.curHP <= 0)
	   {
		   hero.curHP = 0; //if hp less than 0 set to 0 so no negative numbers
		   currentState = TurnState.DEAD;
	   }
	   UpdateHeroPanel();

   }

   void doDamage()
   {
	   float calc_damage = hero.curATK + BSM.PerformList[0].chooseanAttack.attackDamage;
	   EnemyToAttack.GetComponent <EnemyStateMachine>().TakeDamage(calc_damage);
   }

   void CreateHeroPanel()//creates a new panel for whichever hero is dead
	   {
		   HeroPanel = Instantiate(HeroPanel) as GameObject;
		   stats = HeroPanel.GetComponent<HeroPanelStats>();
		   stats.HeroName.text = hero.theName;
		   stats.HeroHP.text = "HP: " + hero.curHP;//HP: 456
		   stats.HeroMP.text = "MP: " + hero.curMP;

		   ProgressBar = stats.ProgressBar;
		   HeroPanel.transform.SetParent(HeroPanelSpacer, false); //false takes care of the scalin

	   }

   //update stats on damage / heal
   void UpdateHeroPanel()
   {
	   stats.HeroHP.text = "HP: " + hero.curHP;
	   //when taking damage get reduced get damage amount, and when dead we update hero panel in take damage script
   }
}
*/
