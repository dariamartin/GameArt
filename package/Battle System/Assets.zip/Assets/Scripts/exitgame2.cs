﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class exitgame : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

	public class ExampleClass : MonoBehaviour
	{
		void Update()
		{
			
				Application.Quit();
			
		}
	}
}
