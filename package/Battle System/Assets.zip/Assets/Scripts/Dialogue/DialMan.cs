﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialMan : MonoBehaviour
{
	public string timer;
	public GameObject dialogueBoxTop;
	public GameObject dialogueBoxBottom;
	public GameObject player;
	public bool checkpoint;

	//List<string[,,]> testList = new List<string[,,]>();

	public bool dialogueTopActive;
	public bool dialogueBottomActive;
	public bool dialogueTop;
	public bool dialogueBottom;
	public bool startedDialogue;
	public float Timer;
	public Text dialogueTopText;
	public Text dialogueBottomText;
	public List<string> dialogueLines = new List<string>();
	public int currentLine;
	// Use this for initialization
	void Start()
	{
		checkpoint = true;
		player = GameObject.Find("Player");
	}

	// Update is called once per frame
	void Update()
	{
		Debug.Log(currentLine);
		if (checkpoint)
			StartCoroutine(TimeForAction());
	}
	private IEnumerator TimeForAction()
	{
			checkpoint = false;
		if (!startedDialogue)
		{
			if (dialogueTop)
			{
				Debug.Log("Going to next line");
				currentLine++;
			}
			else
			{
				currentLine++;
			}
		}

		









		if (currentLine >= dialogueLines.Count)
		{
			if (dialogueTop)
			{
				dialogueBoxTop.SetActive(false);
				dialogueTopActive = false;
				currentLine = 0;
				//Vector3 moveDirection = new Vector3(-25f * 5, 0f, 0f);
				//player.transform.Translate(1f, 1f, 1f);
				//player.myRigidbody.velocity = moveDirection ;
			}
			else
			{
				dialogueBoxBottom.SetActive(false);
				dialogueBottomActive = false;
				currentLine = 0;
			}


		}
		if (dialogueTop)
			dialogueTopText.text = dialogueLines[currentLine];
		else
			dialogueBottomText.text = dialogueLines[currentLine];
		startedDialogue = false;
			yield return new WaitForSeconds(9f);
	checkpoint = true;
		
	}

		
	public void ShowDialogue()
	{
		Debug.Log("Showing Dialogue");
		if (dialogueTop)
		{
			Debug.Log("Top Dialogue");

			dialogueTopActive = true;
			dialogueBoxTop.SetActive(true);
		}
		else
		{
			Debug.Log("Bot Dialogue");

			dialogueBottomActive = true;
			dialogueBoxBottom.SetActive(true);
		}
	}
}
