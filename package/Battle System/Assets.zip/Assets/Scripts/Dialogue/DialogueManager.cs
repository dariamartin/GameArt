﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour {

	public GameObject dialogueBoxTop;
	public GameObject dialogueBoxBottom;
	public GameObject player;
	
	//List<string[,,]> testList = new List<string[,,]>();

	public bool dialogueTopActive;
	public bool dialogueBottomActive;
	public bool dialogueTop;
	public bool dialogueBottom;
	public bool startedDialogue;

	public Text dialogueTopText;
	public Text dialogueBottomText;
	public List<string> dialogueLines = new List<string>();
	public int currentLine;
	// Use this for initialization
	void Start () {
		player = GameObject.Find("Player");
	}
	
	// Update is called once per frame
	void Update () {
		if ((dialogueTopActive || dialogueBottomActive) && Input.GetKeyDown(KeyCode.Space))
		{	if (!startedDialogue)
			{
				if (dialogueTop)
				{
					Debug.Log("Going to next line");
					currentLine++;
				}
				else
				{
					currentLine++;
				}
			}
		}
		if (currentLine >= dialogueLines.Count)
		{
			if (dialogueTop)
			{
				dialogueBoxTop.SetActive(false);
				dialogueTopActive = false;
				currentLine = 0;
				//Vector3 moveDirection = new Vector3(-25f * 5, 0f, 0f);
				//player.transform.Translate(1f, 1f, 1f);
				//player.myRigidbody.velocity = moveDirection ;
			}
			else
			{
				dialogueBoxBottom.SetActive(false);
				dialogueBottomActive = false;
				currentLine = 0 ;
			}

			
		}
		if (dialogueTop) 
		dialogueTopText.text = dialogueLines[currentLine];
		else
			dialogueBottomText.text = dialogueLines[currentLine];
		startedDialogue = false;
	}
	/*public void ShowBox(string dialogue)
		{

			if (dialogueTop)
			{
				dialogueTopActive = true;
				dialogueBoxTop.SetActive(true);
			dialogueText.text = dialogue;
			}
			else
			{
				dialogueBottomActive = true;
				dialogueBoxBottom.SetActive(true);
			dialogueText.text = dialogue;
			}
			
		}*/
	public void ShowDialogue()
	{
		Debug.Log("Showing Dialogue");
		if (dialogueTop)
		{
			Debug.Log("Top Dialogue");

			dialogueTopActive = true;
			dialogueBoxTop.SetActive(true);
		}
		else
		{
			Debug.Log("Bot Dialogue");

			dialogueBottomActive = true;
			dialogueBoxBottom.SetActive(true);
		}
	}
}
