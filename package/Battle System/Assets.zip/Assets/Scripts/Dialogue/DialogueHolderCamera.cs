﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class DialogueHolderCamera : MonoBehaviour
{
	float Timer;
	public string dialogue;
	public List<string> dialogueLines = new List<string>();
	private DialMan dMan;
	private DialMan dMan2;
	public bool dialogueTop;
	public bool dialogueBottom;
	public bool checkpoint = false;
	// Use this for initialization
	void Start()
	{

		dMan = FindObjectOfType<DialMan>();
		dMan2 = GameObject.Find("Canvas").GetComponent<DialMan>();
		if (!dMan.dialogueTopActive && !dMan.dialogueBottomActive)
		{

			dMan.dialogueLines = dialogueLines;
			dMan.currentLine = 0;
			dMan.ShowDialogue();
			dMan2.startedDialogue = true;
		}
	}

	// Update is called once per frame
	void Update()
	{
	}
}
