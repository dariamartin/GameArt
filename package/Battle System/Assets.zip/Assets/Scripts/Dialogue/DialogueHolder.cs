﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class DialogueHolder : MonoBehaviour {
	
	public string dialogue;
	public List<string> dialogueLines = new List<string>();
	private DialogueManager dMan;
	private DialogueManager dMan2;
	public bool dialogueTop;
	public bool dialogueBottom;
	// Use this for initialization
	void Start () {

		dMan = FindObjectOfType<DialogueManager>();
		dMan2 = GameObject.Find("Canvas").GetComponent<DialogueManager>();
	}	
	
	// Update is called once per frame
	void Update () {
		dMan2.dialogueTop = dialogueTop;
		dMan2.dialogueBottom = dialogueBottom;
		
		}

	void OnTriggerStay2D(Collider2D other)
	{
		Debug.Log("Collid");
		if (other.gameObject.name == "Player");
		{
			if (Input.GetKeyDown(KeyCode.Space))
			{
				Debug.Log("Hitting space");
				//dMan.ShowBox(dialogue);
				if (!dMan.dialogueTopActive && !dMan.dialogueBottomActive)
				{
					
					dMan.dialogueLines = dialogueLines;
					dMan.currentLine = 0;
					dMan.ShowDialogue();
					dMan2.startedDialogue = true;
				}
			}
		}
	}
}
