﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    public static GameManager instance;
    //Class Random Monster

    public RegionData curRegions;
    //spawn point
    public string nextSpawnPoint;

    
    //hero
    public GameObject Player;

    //postion
    public Vector3 nextHeroPosition;
    public Vector3 lastHeroPosition; // battle

    //SCENCE
    public string sceneToLoad;
    public string lastScene; //battle

    public bool isWalking = false;
    public bool Ecnounterable = false;
    public bool GetintoBattle = false;

    public enum GameStates
    {
        WORLD_STATE,
        TOWN_STATE,
        BATTLE_STATE,
        IDLE
    }

    //battle
    public int enmeyEcounter;
    public List<GameObject> enemyToBattle = new List<GameObject>();

    public GameStates gamestate;
    void Awake()
    {
        //check instance exist
        if(instance == null)
        {
            //set instance to this if not occur
            instance = this;
        }
        //if it exist but is not this instance
        else if (instance != this)
        {
            //destroy
            Destroy(gameObject);

        }
        //set this to be not destroyable
        DontDestroyOnLoad(gameObject);
        if(!GameObject.Find("Hero"))
        {
            GameObject Hero = Instantiate(Player, nextHeroPosition, Quaternion.identity) as GameObject;
            Hero.name = "Hero";
        }
    }
    void Update()
    {
        switch (gamestate)
        {
            case (GameStates.WORLD_STATE):
                if (isWalking)
                {
                    RandomEncouter();
                }
                if (GetintoBattle)
                {
                    gamestate = GameStates.BATTLE_STATE;
                }
                break;
            case (GameStates.TOWN_STATE):
                break;
            case (GameStates.BATTLE_STATE):
                //start battle
                StateBattle();
                //idle
                gamestate = GameStates.IDLE;
                break;
            case (GameStates.IDLE):
                break;

        }
    }

    public void LoadNextScene()
    {
        SceneManager.LoadScene(sceneToLoad);
    }
    public void LoadSceneAfterCombat()
    {
        SceneManager.LoadScene(lastScene);
    }

    void RandomEncouter()
    {
        if (isWalking && Ecnounterable) 
        {
                if(Random.Range(0,1000) < 10)
                {
                print("get into Battle");
                    GetintoBattle = true;
                }
        }
    }
    void StateBattle()
    {
        //Enenmy amount
        enmeyEcounter = Random.Range(1, curRegions.MaxEnemy + 1);
        //which enemy
        for (int i = 0; i < enmeyEcounter; i++)
        {
            enemyToBattle.Add(curRegions.possibleEnemy[Random.Range(0, curRegions.possibleEnemy.Count)]);
            lastHeroPosition = GameObject.Find("Hero").gameObject.transform.position;
            nextHeroPosition = lastHeroPosition;
            lastScene = SceneManager.GetActiveScene().name;
            //load level
            SceneManager.LoadScene(curRegions.BattleScene);
            //reset hero
            isWalking = false;
            Ecnounterable = false;
            GetintoBattle = false;

        }
    }
}
