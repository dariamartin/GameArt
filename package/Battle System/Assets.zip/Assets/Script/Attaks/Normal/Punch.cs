﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Punch : BaseAttack
{ 
    public Punch()
    {
        AtkName = "Punch";
        AtkDescription = "Strong hand fist Punch";
        AtkDmg = 5f;
        AtkCost = 0;
   
    }
	
}
