﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RegionData : MonoBehaviour {

    public int MaxEnemy = 2;
    public string BattleScene;
    public List<GameObject> possibleEnemy = new List<GameObject>();

}
