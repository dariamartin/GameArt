﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class EnemyStat : MonoBehaviour {
    public Text EnemyName;
    public Text EnemyHP;
    public Text EnemyMP;
    public Image ProgressBar;
}
