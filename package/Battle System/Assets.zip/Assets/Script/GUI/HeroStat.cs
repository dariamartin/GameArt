﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class HeroStat : MonoBehaviour {

    public Text HeroName;
    public Text HeroHP;
    public Text HeroMP;
    public Image ProgressBar;
}
