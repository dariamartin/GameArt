﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionHandler : MonoBehaviour {

    public string sceneToload;
    public string spawnPointName;
    //public GameObject spawnpoint;

}
