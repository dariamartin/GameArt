﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {
    public float speed = 100f;

    Vector3 curPos, lastPos;



	// Use this for initialization
	void Start () {
        if (GameManager.instance.nextSpawnPoint != "")
        {
            GameObject spawnPoint = GameObject.Find(GameManager.instance.nextSpawnPoint);
            transform.position = spawnPoint.transform.position;

            GameManager.instance.nextSpawnPoint = "";
        }
        else if (GameManager.instance.lastHeroPosition != Vector3.zero)
        {
            transform.position = GameManager.instance.lastHeroPosition;
            GameManager.instance.lastHeroPosition = Vector3.zero;
        }
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        float moveX = Input.GetAxis("Horizontal");
        float moveY = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveX, moveY, 0.0f);
        GetComponent<Rigidbody2D>().velocity = movement * speed * Time.deltaTime;

        curPos = transform.position;
        if(curPos == lastPos)
        {
            GameManager.instance.isWalking = false;
        }else
        {
            GameManager.instance.isWalking = true;
        }
        lastPos = curPos;
	}
    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Teleporter")
        {
            CollisionHandler col = other.gameObject.GetComponent<CollisionHandler>();
            GameManager.instance.nextSpawnPoint = col.spawnPointName;
            GameManager.instance.sceneToLoad = col.sceneToload;
            GameManager.instance.LoadNextScene();
        }

        if (other.tag == "EncounterZone")
        {
            RegionData region = other.GetComponent<RegionData>();
            GameManager.instance.curRegions = region;
        }
        
    }
        void OnTriggerStay2D(Collider2D other)
    {
        if (other.tag == "EncounterZone")
        {
            GameManager.instance.Ecnounterable = true;
        }

    }
    
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "EncounterZone")
        {
            GameManager.instance.Ecnounterable = false; 
        }

    }

}
